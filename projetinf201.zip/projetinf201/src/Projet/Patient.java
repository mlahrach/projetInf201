package Projet;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;


public class Patient {
	
	// D�finition des propri�t�s de la classe
	private int numPatient;
	private String nom;
	private String prenom;
	private Date dateNaissance;
	private int sexe;
	ArrayList<Hospitalisation> listeSejours = new ArrayList<>();
	
	
	// D�finition des getters et setters	
	public int getNumPatient() {
		return numPatient;
	}
	public void setNumPatient(int numPatient) {
		this.numPatient = numPatient;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public Date getDateNaissance() {
		return dateNaissance;
	}
	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	public int getSexe() {
		return sexe;
	}
	public void setSexe(int sexe) {
		this.sexe = sexe;
	}
	public ArrayList<Hospitalisation> getListeSejours() {
		return listeSejours;
	}
	public void setListeSejours(ArrayList<Hospitalisation> listeSejours) {
		this.listeSejours = listeSejours;
	}


	// D�finition des constructeurs
	public Patient(int numPatient, String nom, String prenom, Date dateNaissance, int sexe) {
		super();
		this.numPatient = numPatient;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
		this.sexe = sexe;
	}


	public Patient(int numPatient) {
		super();
		this.numPatient = numPatient;
	}


	// D�finition de m�thodes permettant l'affichage de certaines informations
	public String Identit�() {
		return "Nom : " + nom + "\t Pr�nom : " + prenom + "\t Date de naissance : "
				+ dateNaissance + "\t Sexe : " + sexe;
	}
	
	
	public String Sejours() {
		String lesSejours =" - N� d'hospitalisation : ";
		Iterator<Hospitalisation> it = this.getListeSejours().iterator();
		while (it.hasNext()) {
			lesSejours += it.next().getNumHospitalisation();
		}
		return(lesSejours);
	}
	


	
	
	

}
