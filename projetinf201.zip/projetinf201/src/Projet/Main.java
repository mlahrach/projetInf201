package Projet;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
    	// Param�tres de connexion
        String url = "jdbc:mysql://localhost/projetInf201";
        String user = "root";   
        String password = "";
        Connection con = null;
        
        
        try
        {
            // Connexion � la base de donn�es
        	Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(url, user, password);
            System.out.println("Connect�\n ");
            
            
            // Requ�te pr�liminaire : affichage des codes CCAM existants
            
            java.sql.Statement stt = con.createStatement();
            ResultSet res = stt.executeQuery("SELECT CodeCCAM FROM ths_ccam");		//Ex�cution de la requ�te SQL
            System.out.println("Codes CCAM possibles : \n");
            while (res.next()){
            	System.out.println(res.getString(1));	//Affichage du r�sultat de la requ�te
            }
            
            
            
            while (true) {			// Permet d'effectuer les requ�tes suivantes pour plusieurs valeurs du param�tre en entr�e 
            	
         // Requ�te 1 : affichage du libell� CCAM
            	
            Scanner sc = new Scanner(System.in);
            System.out.println("\n Entrez un code CCAM : \n Tapez quit pour quitter");
            String x = sc.nextLine(); 		// Lecture du code CCAM en entr�e
            
            if (x.equals("quit")) break;	// Condition de sortie de la boucle
            
            PreparedStatement pstt1 = con.prepareStatement("SELECT LibelleCCAM FROM ths_ccam WHERE CodeCCAM=?;");
            pstt1.setString(1, x); 		//D�finition du param�tre de la requ�te (Code CCAM en entr�e)
            ResultSet res1 = pstt1.executeQuery();		//Ex�cution de la requ�te param�tr�e
                
            while(res1.next())
            {
            Acte acte = new Acte(res1.getString(1));		// Cr�ation d'un objet acte dans lequel est stock� le r�sultat de la requ�te
            System.out.println("\n L'acte n�" + x + " correspond � : " + acte.getLibelleCCAM() + ".");
            }
            
            if(res1.first()==false) {System.out.println("\n Ce code ne correspond pas � un code CCAM. \n");};	//Message d'erreur si la requ�te ne retourne pas de r�sultat donc si la premi�re ligne du ResultSet est vide
            
            
            // Requ�te 2 : affichage de l'identifiant du dernier patient concern� par cet acte
            
            PreparedStatement pstt2 = con.prepareStatement("SELECT NumPatient\r\n" + 
            		"FROM tab_hospitalisation h INNER JOIN tab_acte a ON h.NumHospitalisation=a.NumHopitalisation\r\n" + 
            		"WHERE CodeCCAM=?\r\n" + 
            		"ORDER BY DateActe DESC\r\n" + 
            		"LIMIT 1");
            pstt2.setString(1, x);		// On r�utilise le param�tre de la requ�te pr�c�dente
            ResultSet res2 = pstt2.executeQuery();
            int y = 0; // on initialise cette variable qui nous permettra de conserver ensuite le numPatient pour le r�utiliser dans les requ�tes suivantes
            while(res2.next())
            {
            	Patient patient = new Patient(res2.getInt(1));
            	y = patient.getNumPatient(); //Stocke le numPatient pour le r�utiliser
            	System.out.println("Cet acte (" + x + ") a �t� pratiqu� pour la derni�re fois chez le patient n� " + y + ". \n");
            }
            
            if(res2.first()==false) {System.out.println("Cet acte n'a pas encore �t� pratiqu�. \n");};
            
            
            // Requ�te 3 : affichage de l'identit� du patient
            
            PreparedStatement pstt3 = con.prepareStatement("SELECT * FROM tab_patient WHERE NumPatient =?;");
            pstt3.setInt(1, y);		//On utilise le numPatient stock� dans la requ�te pr�c�dente
            ResultSet res3 = pstt3.executeQuery();
            
            while(res3.next())
            {
            	Patient patient = new Patient(y, res3.getString(5), res3.getString(4), res3.getDate(3), res3.getInt(2));
            	System.out.println("Identit� du patient n�" + y + " : \n" + patient.Identit�() + "\n");
            	
            }
            
            
            // Requ�te 4 : affichage de la liste des hospitalisations du patient

            PreparedStatement pstt4 = con.prepareStatement("SELECT NumHospitalisation FROM tab_hospitalisation WHERE NumPatient =?;");
            pstt4.setInt(1, y);
            ResultSet res4 = pstt4.executeQuery();
            if(y==0) {System.out.println("");} else {System.out.println("Liste des s�jours du patient n�" + y + " :");}
           
            while(res4.next())
            {
            	Patient patient = new Patient (y);		// Cr�ation d'un objet patient qui prend le numPatient issu des requ�tes pr�c�dentes
            	Hospitalisation hospit = new Hospitalisation(res4.getInt(1));	//Cr�ation d'un objet hospitalisation dans lequel est stock� le r�sultat de la requ�te
            	patient.getListeSejours().add(hospit);		//Ajout de l'objet hospit (qui comprend un numHospitalisation) dans la liste des S�jours du patient concern�
            	
            	System.out.println(patient.Sejours());
            } 
             
            }
            
              
            
}
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {					// Fermeture de la connexion
        	if (con !=null)
        		try {
        			con.close();
        		}catch (SQLException ignore) {
        			ignore.printStackTrace();
        		}
        }
    }

    }

