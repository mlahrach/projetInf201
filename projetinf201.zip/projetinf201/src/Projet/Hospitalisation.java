package Projet;

import java.util.Date;

public class Hospitalisation {
	
	// D�finition des propri�t�s de la classe
	private int numHospitalisation;
	private int numPatient;
	private Date dateEntree;
	private Date dateSortie;
	
	
	
	// D�finition des getters et setters	
	public int getNumHospitalisation() {
		return numHospitalisation;
	}

	public void setNumHospitalisation(int numHospitalisation) {
		this.numHospitalisation = numHospitalisation;
	}

	public int getNumPatient() {
		return numPatient;
	}

	public void setNumPatient(int numPatient) {
		this.numPatient = numPatient;
	}

	public Date getDateEntree() {
		return dateEntree;
	}

	public void setDateEntree(Date dateEntree) {
		this.dateEntree = dateEntree;
	}

	public Date getDateSortie() {
		return dateSortie;
	}

	public void setDateSortie(Date dateSortie) {
		this.dateSortie = dateSortie;
	}

		
	// D�finition d'un constructeur	
	public Hospitalisation(int numHospitalisation) {
		super();
		this.numHospitalisation = numHospitalisation;
	}
}
