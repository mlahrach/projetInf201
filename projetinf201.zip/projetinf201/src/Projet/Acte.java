package Projet;

import java.util.Date;


public class Acte {
	
	// D�finition des propri�t�s de la classe
	private int numActe;
	private int numHospitalisation;
	private String codeCCAM;
	private String libelleCCAM;
	private Date dateActe;
	private int anesthesie;
		
	
	// D�finition des getters et setters	
	public String getLibelleCCAM() {
		return libelleCCAM;
	}
	public void setLibelleCCAM(String libelleCCAM) {
		this.libelleCCAM = libelleCCAM;
	}
	public int getNumActe() {
		return numActe;
	}
	public void setNumActe(int numActe) {
		this.numActe = numActe;
	}
	public int getNumHospitalisation() {
		return numHospitalisation;
	}
	public void setNumHospitalisation(int numHospitalisation) {
		this.numHospitalisation = numHospitalisation;
	}
	public String getCodeCCAM() {
		return codeCCAM;
	}
	public void setCodeCCAM(String codeCCAM) {
		this.codeCCAM = codeCCAM;
	}
	public Date getDateActe() {
		return dateActe;
	}
	public void setDateActe(Date dateActe) {
		this.dateActe = dateActe;
	}
	public int getAnesthesie() {
		return anesthesie;
	}
	public void setAnesthesie(int anesthesie) {
		this.anesthesie = anesthesie;
	}
	
		
	// D�finition d'un constructeur
	public Acte(String libelleCCAM) {
		super();
		this.libelleCCAM = libelleCCAM;
	}
	
	
	
}
